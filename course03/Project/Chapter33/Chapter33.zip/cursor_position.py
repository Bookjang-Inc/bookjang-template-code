# pyautogui 모듈을 불러옵니다.
import pyautogui

while True:
    #마우스 커서의 위치를 계속 출력합니다.
    print()